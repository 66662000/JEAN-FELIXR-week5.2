package Core;

import java.util.Scanner;

public class primeNumberOrNot {

	  public static void main(String[] args) {

		  System.out.println("Enter the number witch you want to test primarity:");
		  @SuppressWarnings("resource")
		Scanner src = new Scanner(System.in);
		  
		  int number = src.nextInt();
		  
	    
	    boolean cond = false;
	    for (int i = 2; i <= number / 2; ++i) {
	      // If not a prime number
	      if (number % i == 0) {
	        cond = true;
	        break;
	      }
	    }

	    if (!cond)
	      System.out.println(number + " is a prime number.");
	    else
	      System.out.println(number + " is not a prime number.");
	  }
	}
