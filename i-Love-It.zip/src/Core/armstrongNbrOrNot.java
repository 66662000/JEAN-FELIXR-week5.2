package Core;

import java.util.Scanner;



public class armstrongNbrOrNot {

    public static void main(String[] args) {
    	
    	System.out.println("Enter the number wich you want to test:");

    	@SuppressWarnings("resource")
    	Scanner src = new Scanner(System.in);

    	int numberInput = src.nextInt();

        int number = numberInput, origNmbr, remainder, res = 0, n = 0;

        origNmbr = number;

        for (;origNmbr != 0; origNmbr /= 10, ++n);

        origNmbr = number;

        for (;origNmbr != 0; origNmbr /= 10)
        {
            remainder = origNmbr % 10;
            res += Math.pow(remainder, n);
        }

        if(res == number)
            System.out.println(number + " is an Armstrong number.");
        else
            System.out.println(number + " is not an Armstrong number.");
    }
}