package Core;

import java.util.Scanner;

public class sumOfDigit 
{
    int sum = 0;
    public static void main(String[] args) 
    {
        int numInput;
        @SuppressWarnings("resource")
		Scanner src = new Scanner(System.in);
        System.out.print("Enter the number:");
        numInput = src.nextInt();
        sumOfDigit obj = new sumOfDigit();
        int a = obj.add(numInput);
        System.out.println("Sum:"+a);
    }
    int add(int k)
    {
        sum = k % 10;
        if(k == 0)
        {
            return 0;
        }
        else
        {
             return sum + add(k / 10);
        }
 
    }
}
