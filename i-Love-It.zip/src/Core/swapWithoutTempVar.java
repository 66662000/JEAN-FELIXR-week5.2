package Core;

import java.util.Scanner;

public class swapWithoutTempVar {

	 @SuppressWarnings("resource")
	public static void main(String[] args) {

		 String exeption = "(temp)";
		 
		 System.out.println("Enter two numbers and we will swap them without using "+exeption+" variable");
		 System.out.println("Enter the first number:");
		 
		 Scanner src = new Scanner (System.in);
		 
		 int nbr1 = src.nextInt();
		 
		 System.out.println("Enter the second number:");
		 
		 int nbr2 = src.nextInt();
		 
	  

	  System.out.println("Before Swapping");
	  System.out.println("Value of number one is :" + nbr1);
	  System.out.println("Value of number two is :" + nbr2);

	  //add both the numbers and assign it to first
	  nbr1 = nbr1 + nbr2;
	  nbr2 = nbr1 - nbr2;
	  nbr1 = nbr1 - nbr2;

	  System.out.println("After Swapping");
	  System.out.println("Value of number one is :" + nbr1);
	  System.out.println("Value of number two is :" + nbr2);
	 }
	}