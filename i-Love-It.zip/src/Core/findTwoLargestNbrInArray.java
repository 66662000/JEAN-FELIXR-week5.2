package Core;

import java.util.Scanner;
public class findTwoLargestNbrInArray
{
	@SuppressWarnings("resource")
	public static void main (String[] args)
	{
		Scanner scr = new Scanner (System.in);
		System.out.print("How many number do you want to enter?:");
                int nbrChoice = scr.nextInt();
 
		int myarray[] = new int[nbrChoice];
                System.out.println("Enter all the elements:");
		for (int i = 0; i < myarray.length; i++)
		{
			if(i==0)
			{

                System.out.println("Enter the first element:");
                myarray[i] = scr.nextInt();
			}
			
			if(i==myarray.length-1)
			{
				System.out.println("Enter the last element:");
                myarray[i] = scr.nextInt();
			}
			
			if(i>0 && i < myarray.length-1)
			{
				System.out.println("Enter the next element:");
                myarray[i] = scr.nextInt();
			}
			
		}
 
		int bigest1, bigest2, temp;
 
		bigest1 = myarray[0];
		bigest2 = myarray[1];
 
		if (bigest1 < bigest2)
		{
			temp = bigest1;
			bigest1 = bigest2;
			bigest2 = temp;
		}
 
		for (int i = 2; i < myarray.length; i++)
		{
			if (myarray[i] > bigest1)
			{
				bigest2 = bigest1;
				bigest1 = myarray[i];
			}
			else if (myarray[i] > bigest2 && myarray[i] != bigest1)
			{
				bigest2 = myarray[i];
			}
		}
 
		System.out.println ("The First biggest number is " + bigest1);
		System.out.println ("The Second biggest number is " + bigest2);
 
	}
}