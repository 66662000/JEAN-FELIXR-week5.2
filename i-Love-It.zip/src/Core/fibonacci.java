package Core;

import java.util.Scanner;

public class fibonacci{  
	
@SuppressWarnings("resource")
public static void main(String args[])  

{    
	System.out.println("Enter your fibonacci sery length: ");
	
	Scanner src = new Scanner (System.in);
	
	int counter = src.nextInt();

	int number1=0,number2=1,number3,index;    
 
	System.out.print(number1+" "+number2);//printing 0 and 1    
    

	for(index=2;index<counter;++index)//loop starts from 2 because 0 and 1 are already printed    

	{    
  
		number3=number1+number2;    
  
		System.out.print(" "+number3);    
  
		number1=number2;    
  
 
		number2=number3;    
 
	}    
  
}}
