package Core;

import java.util.Scanner;

public class duPlicateChar_String {  
    @SuppressWarnings("resource")
	public static void main(String[] args) {  

        System.out.println("Enter your text and you will find the duplicated characters: ");
        Scanner src = new Scanner(System.in);
        
        String myText = src.nextLine();
        
 
       int count;  
         
  
       char string[] = myText.toCharArray();  
         
       System.out.println("The duplicated characters in your string: ");  
      
       for(int i = 0; i <string.length; i++) {  
           count = 1;  
           for(int j = i+1; j <string.length; j++) {  
               if(string[i] == string[j] && string[i] != ' ') {  
                   count++;  
                  
                   string[j] = '0';  
               }  
           }  
           
           if(count > 1 && string[i] != '0')  
               System.out.println(string[i]);  
       }  
   }  
}  
