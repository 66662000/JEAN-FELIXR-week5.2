package Core;

	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.Comparator;
	import java.util.HashMap;
	import java.util.List;
	import java.util.Map;
	import java.util.Set;
	import java.util.Map.Entry;
	 
	public class mapSort {
	 
	    public static void main(String a[]){
	        Map<String, Integer> mymap = new HashMap<String, Integer>();
	        mymap.put("ESIH", 20);
	        mymap.put("Kiskeya", 45);
	        mymap.put("SchoolOf future", 2);
	        mymap.put("UP", 67);
	        mymap.put("HIEC", 26);
	        mymap.put("Hotel", 93);
	        Set<Entry<String, Integer>> myset = mymap.entrySet();
	        List<Entry<String, Integer>> mylist = new ArrayList<Entry<String, Integer>>(myset);
	        Collections.sort( mylist, new Comparator<Map.Entry<String, Integer>>()
	        {
	            public int compare( Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2 )
	            {
	                return (o2.getValue()).compareTo( o1.getValue() );
	            }
	        } );
	        for(Map.Entry<String, Integer> entry:mylist){
	            System.out.println(entry.getKey()+" ====> "+entry.getValue());
	        }
	    }
	}
