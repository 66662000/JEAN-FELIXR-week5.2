package Core;

import java.util.Scanner;

public class binaryToDecimalNbr {

    public static int toDecimal(String str) {     

    	int decimalNbr = Integer.parseInt(str,2);
        
    	return decimalNbr;
    }


    public static boolean isBinary(String op) {
    
    	int inputNum = Integer.parseInt(op);

        while(inputNum != 0){
            if(inputNum % 10 > 1){
                return false;
            }
            inputNum = inputNum / 10;
        }
        return true;
    }

    @SuppressWarnings({ "unused", "resource" })
	public static void main(String[] args) {

        System.out.print("Enter your binary number : ");
        Scanner src = new Scanner(System.in);
        String binaryNum = src.next();

        try{
            int intNum = Integer.parseInt(binaryNum);

            boolean isBinary = isBinary(binaryNum);
            if(isBinary){
                int outputDecimal = toDecimal(binaryNum);
                System.out.println("\nThe binary number: "+binaryNum+" is "+ outputDecimal +" in decimal");
            }else{
                System.out.println("\n" + "Not a good binary number!");
            }
        }catch(Exception e){
            System.out.println("\n" + "Not a good binary number!");
        }
    }
}